const enc = new TextEncoder();
const json = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers: {"content-type":"application/json; charset=utf-8","cache-control":"no-store"}
});
const toB64 = bytes => {
  let s=""; for (const b of bytes) s += String.fromCharCode(b); return btoa(s);
};
const fromB64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
async function hmac(keyBytes, message) {
  const key = await crypto.subtle.importKey("raw", keyBytes, {name:"HMAC",hash:"SHA-256"}, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, enc.encode(message)));
}
function safeEqual(a,b) {
  if (a.length !== b.length) return false;
  let diff=0; for(let i=0;i<a.length;i++) diff |= a[i]^b[i]; return diff===0;
}
async function validateInitData(raw, botToken) {
  if (!raw || !botToken) throw new Error("Telegram authentication is not configured.");
  const p = new URLSearchParams(raw), supplied = p.get("hash"), authDate = Number(p.get("auth_date"));
  if (!supplied || !Number.isFinite(authDate)) throw new Error("Invalid Telegram init data.");
  const now = Math.floor(Date.now()/1000);
  if (authDate > now+30 || now-authDate > 86400) throw new Error("Telegram session expired. Reopen the Mini App.");
  p.delete("hash"); p.delete("signature");
  const check = [...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join("\n");
  const secret = await hmac(enc.encode("WebAppData"), botToken);
  const actual = await hmac(secret, check);
  const expected = Uint8Array.from(supplied.match(/.{1,2}/g)||[], x=>parseInt(x,16));
  if (!safeEqual(actual,expected)) throw new Error("Telegram signature validation failed.");
  const user = JSON.parse(p.get("user") || "null");
  if (!user?.id) throw new Error("Telegram user is missing.");
  return user;
}
async function requireUser(req, env) {
  const auth=req.headers.get("authorization")||"";
  if (!auth.startsWith("tma ")) throw new Error("Open BirrTask inside Telegram.");
  const tg=await validateInitData(auth.slice(4),env.BOT_TOKEN);
  await env.DB.prepare(`INSERT INTO users(telegram_id,first_name,username) VALUES(?,?,?)
    ON CONFLICT(telegram_id) DO UPDATE SET first_name=excluded.first_name,
    username=excluded.username,updated_at=unixepoch()`)
    .bind(String(tg.id),String(tg.first_name||"Telegram user"),tg.username||null).run();
  return await env.DB.prepare(`SELECT id,telegram_id,first_name,username,balance_cents,lifetime_earned_cents
    FROM users WHERE telegram_id=?`).bind(String(tg.id)).first();
}
function requireAdmin(req,env) {
  if (!env.ADMIN_TOKEN || req.headers.get("authorization") !== `Bearer ${env.ADMIN_TOKEN}`)
    throw new Error("Admin authorization failed.");
}
const etb = cents => Number(cents||0)/100;
async function encryptPhone(phone,env) {
  if (!env.PAYMENT_ENCRYPTION_KEY) throw new Error("Payment encryption key is not configured.");
  const raw=fromB64(env.PAYMENT_ENCRYPTION_KEY);
  if(raw.length!==32) throw new Error("Payment encryption key must decode to 32 bytes.");
  const key=await crypto.subtle.importKey("raw",raw,"AES-GCM",false,["encrypt"]);
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const cipher=await crypto.subtle.encrypt({name:"AES-GCM",iv},key,enc.encode(phone));
  return {ciphertext:toB64(new Uint8Array(cipher)),iv:toB64(iv)};
}
async function decryptPhone(ciphertext,ivText,env) {
  const raw=fromB64(env.PAYMENT_ENCRYPTION_KEY);
  const key=await crypto.subtle.importKey("raw",raw,"AES-GCM",false,["decrypt"]);
  const plain=await crypto.subtle.decrypt({name:"AES-GCM",iv:fromB64(ivText)},key,fromB64(ciphertext));
  return new TextDecoder().decode(plain);
}
async function postback(url,env) {
  const q=url.searchParams;
  if(!env.MONETAG_POSTBACK_SECRET || q.get("secret")!==env.MONETAG_POSTBACK_SECRET)
    return new Response("forbidden",{status:403});
  const ymid=q.get("ymid");
  if(!ymid || q.get("event_type")!=="impression") return new Response("ignored",{status:200});
  const s=await env.DB.prepare("SELECT * FROM ad_sessions WHERE ymid=?").bind(ymid).first();
  if(!s || s.status!=="pending") return new Response("already processed or unknown session",{status:200});
  if(q.get("reward_event_type")!=="valued") {
    await env.DB.prepare("UPDATE ad_sessions SET status='non_valued' WHERE ymid=? AND status='pending'").bind(ymid).run();
    return new Response("not valued",{status:200});
  }
  const usd=Number(q.get("estimated_price"));
  const rate=Number(env.USD_ETB_RATE||0), share=Number(env.REWARD_SHARE_BPS||0);
  if(!Number.isFinite(usd)||usd<=0||!Number.isFinite(rate)||rate<=0||!Number.isFinite(share)||share<=0||share>10000)
    return new Response("reward conversion is not configured",{status:503});
  const cents=Math.floor(usd*rate*(share/10000)*100);
  const status=cents>0?"credited":"below_minimum";
  await env.DB.prepare(`INSERT OR IGNORE INTO reward_events(ymid,user_id,publisher_usd,amount_cents,status)
    SELECT ?,?,?,?,? WHERE EXISTS(
      SELECT 1 FROM ad_sessions WHERE ymid=? AND user_id=? AND status='pending' AND created_at>=?)`)
    .bind(ymid,s.user_id,usd,cents,status,ymid,s.user_id,Math.floor(Date.now()/1000)-86400).run();
  return new Response("ok",{status:200});
}
async function api(req,env,url) {
  const p=url.pathname,m=req.method;
  if(p==="/api/config"&&m==="GET") return json({
    appName:env.APP_NAME||"BirrTask",dailyAdLimit:Number(env.DAILY_AD_LIMIT||5),
    minWithdrawalEtb:Number(env.MIN_WITHDRAWAL_ETB||100),
    sdkEnabled:Boolean(env.MONETAG_SDK_SRC&&env.MONETAG_ZONE_ID),
    sdkSrc:env.MONETAG_SDK_SRC||"",zoneId:env.MONETAG_ZONE_ID||""
  });

  if(p.startsWith("/api/admin/")) {
    requireAdmin(req,env);
    if(p==="/api/admin/overview"&&m==="GET") {
      const totals=await env.DB.prepare(`SELECT
        (SELECT COUNT(*) FROM users) users,
        (SELECT COUNT(*) FROM ad_sessions WHERE created_at>=unixepoch('now','-1 day')) ad_attempts_today,
        (SELECT COALESCE(SUM(amount_cents),0) FROM reward_events WHERE status='credited') rewards_cents,
        (SELECT COUNT(*) FROM withdrawals WHERE status='pending') pending_withdrawals`).first();
      const rows=await env.DB.prepare(`SELECT w.*,u.telegram_id,u.first_name FROM withdrawals w
        JOIN users u ON u.id=w.user_id ORDER BY w.created_at DESC LIMIT 50`).all();
      const withdrawals=[];
      for(const r of rows.results||[]) withdrawals.push({
        id:r.id,amountEtb:etb(r.amount_cents),telebirr:await decryptPhone(r.telebirr_ciphertext,r.telebirr_iv,env),
        status:r.status,createdAt:r.created_at,telegramId:r.telegram_id,firstName:r.first_name
      });
      return json({totals,withdrawals});
    }
    const match=p.match(/^\/api\/admin\/withdrawals\/(\d+)$/);
    if(match&&m==="POST") {
      const body=await req.json();
      if(!["paid","rejected"].includes(body.status)) return json({error:"Status must be paid or rejected."},400);
      const r=await env.DB.prepare(`UPDATE withdrawals SET status=?,admin_note=?,updated_at=unixepoch()
        WHERE id=? AND status='pending'`).bind(body.status,String(body.note||"").slice(0,300),Number(match[1])).run();
      if(!r.meta?.changes) return json({error:"Request not found or already processed."},409);
      return json({ok:true});
    }
    return json({error:"Admin route not found."},404);
  }

  if(p==="/api/me"&&m==="GET") {
    const u=await requireUser(req,env),day=Math.floor(Date.now()/86400000)*86400;
    const count=await env.DB.prepare("SELECT COUNT(*) count FROM ad_sessions WHERE user_id=? AND created_at>=?").bind(u.id,day).first();
    const hist=await env.DB.prepare("SELECT type,amount_cents,reference,created_at FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 30").bind(u.id).all();
    return json({
      user:{firstName:u.first_name,username:u.username,balanceEtb:etb(u.balance_cents),lifetimeEarnedEtb:etb(u.lifetime_earned_cents)},
      adsUsedToday:count?.count||0,dailyAdLimit:Number(env.DAILY_AD_LIMIT||5),
      history:(hist.results||[]).map(x=>({type:x.type,amountEtb:etb(x.amount_cents),reference:x.reference,createdAt:x.created_at}))
    });
  }

  if(p==="/api/ad/start"&&m==="POST") {
    const u=await requireUser(req,env);
    if(!env.MONETAG_SDK_SRC||!env.MONETAG_ZONE_ID) return json({error:"Rewarded ads are not connected yet."},503);
    const day=Math.floor(Date.now()/86400000)*86400;
    const c=await env.DB.prepare("SELECT COUNT(*) count FROM ad_sessions WHERE user_id=? AND created_at>=?").bind(u.id,day).first();
    if((c?.count||0)>=Number(env.DAILY_AD_LIMIT||5)) return json({error:"Daily ad limit reached."},429);
    const active=await env.DB.prepare("SELECT COUNT(*) count FROM ad_sessions WHERE user_id=? AND status='pending' AND created_at>=?").bind(u.id,Math.floor(Date.now()/1000)-600).first();
    if((active?.count||0)>0) return json({error:"An ad verification is already pending. Wait a moment."},429);
    const ymid=crypto.randomUUID();
    await env.DB.prepare("INSERT INTO ad_sessions(ymid,user_id) VALUES(?,?)").bind(ymid,u.id).run();
    return json({ymid});
  }

  if(p==="/api/ad/client-result"&&m==="POST") {
    const u=await requireUser(req,env),b=await req.json();
    if(!b.ymid) return json({error:"Missing ad session."},400);
    await env.DB.prepare("UPDATE ad_sessions SET client_result=? WHERE ymid=? AND user_id=? AND status='pending'")
      .bind(String(b.result||"unknown").slice(0,40),String(b.ymid),u.id).run();
    // This client callback is UI-only. It never credits a balance.
    return json({ok:true,message:"Waiting for provider verification."});
  }

  if(p==="/api/withdrawals"&&m==="POST") {
    const u=await requireUser(req,env),b=await req.json();
    const amount=Number(b.amountEtb),cents=Math.round(amount*100),phone=String(b.telebirrNumber||"").replace(/\s+/g,"");
    if(!Number.isFinite(amount)||cents<=0) return json({error:"Enter a valid amount."},400);
    if(amount<Number(env.MIN_WITHDRAWAL_ETB||100)) return json({error:`Minimum withdrawal is ${Number(env.MIN_WITHDRAWAL_ETB||100)} ETB.`},400);
    if(!/^(09\d{8}|\+2519\d{8})$/.test(phone)) return json({error:"Enter a valid Ethiopian Telebirr mobile number."},400);
    const encrypted=await encryptPhone(phone,env);
    try {
      await env.DB.prepare("INSERT INTO withdrawals(user_id,amount_cents,telebirr_ciphertext,telebirr_iv) VALUES(?,?,?,?)")
        .bind(u.id,cents,encrypted.ciphertext,encrypted.iv).run();
      return json({ok:true,message:"Withdrawal request submitted for review."});
    } catch(e) {
      if(String(e).includes("insufficient_balance")) return json({error:"Your balance is too low."},400);
      throw e;
    }
  }
  return json({error:"API route not found."},404);
}
export default {
  async fetch(req,env) {
    const url=new URL(req.url);
    try {
      if(url.pathname==="/postback/monetag"&&req.method==="GET") return await postback(url,env);
      if(url.pathname.startsWith("/api/")) return await api(req,env,url);
      return env.ASSETS.fetch(req);
    } catch(e) {
      const msg=String(e?.message||"Server error");
      const status=msg.includes("authorization")||msg.includes("Telegram")||msg.includes("init data")||msg.includes("Open BirrTask")?401:500;
      return json({error:status===500?"Server error. Check Worker logs.":msg},status);
    }
  }
};