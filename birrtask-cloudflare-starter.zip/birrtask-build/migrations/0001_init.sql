PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id TEXT NOT NULL UNIQUE,
  first_name TEXT NOT NULL DEFAULT 'Telegram user',
  username TEXT,
  balance_cents INTEGER NOT NULL DEFAULT 0 CHECK(balance_cents >= 0),
  lifetime_earned_cents INTEGER NOT NULL DEFAULT 0 CHECK(lifetime_earned_cents >= 0),
  created_at INTEGER NOT NULL DEFAULT(unixepoch()),
  updated_at INTEGER NOT NULL DEFAULT(unixepoch())
);

CREATE TABLE IF NOT EXISTS ad_sessions (
  ymid TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK(status IN ('pending','credited','non_valued','below_minimum')),
  client_result TEXT,
  created_at INTEGER NOT NULL DEFAULT(unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_ad_sessions_user_created ON ad_sessions(user_id, created_at);

CREATE TABLE IF NOT EXISTS reward_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ymid TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  publisher_usd REAL NOT NULL DEFAULT 0,
  amount_cents INTEGER NOT NULL DEFAULT 0 CHECK(amount_cents >= 0),
  status TEXT NOT NULL CHECK(status IN ('credited','below_minimum')),
  created_at INTEGER NOT NULL DEFAULT(unixepoch())
);

CREATE TABLE IF NOT EXISTS withdrawals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
  telebirr_ciphertext TEXT NOT NULL,
  telebirr_iv TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid','rejected')),
  admin_note TEXT,
  created_at INTEGER NOT NULL DEFAULT(unixepoch()),
  updated_at INTEGER NOT NULL DEFAULT(unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status_created ON withdrawals(status, created_at DESC);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  type TEXT NOT NULL CHECK(type IN ('ad_reward','withdrawal_request','withdrawal_refund')),
  amount_cents INTEGER NOT NULL,
  reference TEXT NOT NULL,
  created_at INTEGER NOT NULL DEFAULT(unixepoch())
);

CREATE TRIGGER IF NOT EXISTS reward_event_credit
AFTER INSERT ON reward_events
WHEN NEW.status='credited' AND NEW.amount_cents > 0
BEGIN
  UPDATE users SET balance_cents=balance_cents+NEW.amount_cents,
    lifetime_earned_cents=lifetime_earned_cents+NEW.amount_cents,
    updated_at=unixepoch() WHERE id=NEW.user_id;
  UPDATE ad_sessions SET status='credited' WHERE ymid=NEW.ymid;
  INSERT INTO transactions(user_id,type,amount_cents,reference)
    VALUES(NEW.user_id,'ad_reward',NEW.amount_cents,NEW.ymid);
END;

CREATE TRIGGER IF NOT EXISTS reward_event_below_minimum
AFTER INSERT ON reward_events
WHEN NEW.status='below_minimum'
BEGIN
  UPDATE ad_sessions SET status='below_minimum' WHERE ymid=NEW.ymid;
END;

CREATE TRIGGER IF NOT EXISTS withdrawal_check_balance
BEFORE INSERT ON withdrawals
WHEN (SELECT balance_cents FROM users WHERE id=NEW.user_id) < NEW.amount_cents
BEGIN
  SELECT RAISE(ABORT,'insufficient_balance');
END;

CREATE TRIGGER IF NOT EXISTS withdrawal_debit
AFTER INSERT ON withdrawals
BEGIN
  UPDATE users SET balance_cents=balance_cents-NEW.amount_cents,
    updated_at=unixepoch() WHERE id=NEW.user_id;
  INSERT INTO transactions(user_id,type,amount_cents,reference)
    VALUES(NEW.user_id,'withdrawal_request',-NEW.amount_cents,CAST(NEW.id AS TEXT));
END;

CREATE TRIGGER IF NOT EXISTS withdrawal_refund
AFTER UPDATE OF status ON withdrawals
WHEN OLD.status='pending' AND NEW.status='rejected'
BEGIN
  UPDATE users SET balance_cents=balance_cents+NEW.amount_cents,
    updated_at=unixepoch() WHERE id=NEW.user_id;
  INSERT INTO transactions(user_id,type,amount_cents,reference)
    VALUES(NEW.user_id,'withdrawal_refund',NEW.amount_cents,CAST(NEW.id AS TEXT));
END;