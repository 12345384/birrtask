# BirrTask — Cloudflare Workers + D1

A Telegram Mini App starter for rewarded video ads only. It runs on Cloudflare Workers and Cloudflare D1; no Termux or local server is required.

## Included
- Telegram Mini App interface, ETB balance, activity and Telebirr withdrawal requests
- Server-side Telegram `initData` signature validation
- Server-created unique `ymid` for each ad session
- Monetag SDK integration using the publisher-issued script URL and zone ID
- Monetag server-to-server postback; only `valued` impressions can credit a reward
- Idempotent reward ledger and D1 triggers to prevent duplicate credits
- ETB reward calculated from `estimated_price` × configured USD/ETB rate × revenue-share percentage
- AES-GCM encryption of Telebirr numbers at rest
- Admin withdrawal review; rejection automatically refunds the user's balance

## Important
- Provider `estimated_price` is an estimate, not a guaranteed final publisher payout. Never promise a fixed ETB reward per view. Reconcile rewards against actual publisher statements before enabling withdrawals.
- `USD_ETB_RATE` is an operator-maintained conversion input. Update it when appropriate.
- The app does not transfer funds automatically. An authorized operator processes requests through an approved Telebirr channel and marks a request paid only after the transfer succeeds.
- Follow all provider, payment, identity, age, country, and business eligibility requirements. Do not misrepresent identity or bypass account rules. An eligible adult or organization must manage any account that requires it.
- Keep all tokens and secrets in Cloudflare Worker secrets, never in GitHub or chat.
- Before public launch, complete provider moderation, privacy/legal review, fraud testing, backup/recovery checks, and a small end-to-end test.

## 1. Create the D1 database
1. Sign in to Cloudflare and open Workers & Pages → D1.
2. Create a database named `birrtask-db`.
3. Copy its database ID.
4. Edit `wrangler.jsonc` and replace `REPLACE_WITH_YOUR_D1_DATABASE_ID`.
5. Open the D1 SQL Console and run all of `migrations/0001_init.sql`.

## 2. Add source to GitHub
1. Create a new private repository named `birrtask`.
2. Extract the downloaded ZIP on your device.
3. Upload the extracted files/folders to the repository root. Upload the files, not the ZIP itself.
4. Check that `wrangler.jsonc`, `src/`, `public/`, and `migrations/` are at the root.

## 3. Deploy from GitHub
1. In Cloudflare, open Workers & Pages → Create application.
2. Choose GitHub and authorize the repository.
3. Select `birrtask`, then save and deploy as a Worker.
4. Confirm the Worker name matches `name` in `wrangler.jsonc`.
5. Open the generated `https://birrtask.<your-subdomain>.workers.dev` URL.
Official guide: https://developers.cloudflare.com/workers/ci-cd/builds/

## 4. Configure Worker secrets
Add these as **secrets** in Worker settings:
- `BOT_TOKEN` — Telegram bot token
- `ADMIN_TOKEN` — long random admin token
- `MONETAG_POSTBACK_SECRET` — long random secret used only in the postback URL
- `PAYMENT_ENCRYPTION_KEY` — base64 32-byte key generated locally in your browser at `/keygen.html`

Add these as **variables**:
- `MONETAG_ZONE_ID` — exact zone ID from your publisher dashboard
- `MONETAG_SDK_SRC` — exact SDK script URL from your publisher dashboard
- `USD_ETB_RATE` — configured ETB per USD conversion rate
- `REWARD_SHARE_BPS` — `3000` means 30% of estimated event revenue
- `DAILY_AD_LIMIT` — e.g. `5`
- `MIN_WITHDRAWAL_ETB` — e.g. `100`
- `APP_NAME` — `BirrTask`

Do not guess the SDK URL or zone ID. Use the exact publisher-generated script URL and zone ID. The SDK function name is `show_<zone ID>`.

## 5. Configure Monetag postback
In the publisher dashboard, configure the postback for the app's main SDK zone:

```text
https://YOUR-WORKER-URL/postback/monetag?secret=YOUR_LONG_SECRET&ymid={ymid}&event_type={event_type}&reward_event_type={reward_event_type}&estimated_price={estimated_price}
```

Replace the Worker URL and secret. The secret must match `MONETAG_POSTBACK_SECRET`.

The backend grants a reward only when the postback is for an impression, `reward_event_type` is `valued`, the `ymid` matches a recent server-created session, and that `ymid` has not already been processed.

Official docs:
- https://docs.monetag.com/
- https://docs.monetag.com/docs/postbacks/
- https://docs.monetag.com/docs/postbacks/configuration/
- https://docs.monetag.com/docs/ad-integration/sdk-integration/

## 6. Connect Telegram
1. Create or select your Telegram bot in BotFather.
2. Set its Mini App/Web App URL to your Cloudflare Worker URL.
3. Save the bot token as the Worker secret `BOT_TOKEN`.
4. Launch the Mini App inside Telegram. A normal browser does not supply Telegram's signed `initData`.

Telegram docs: https://core.telegram.org/bots/webapps

## 7. Admin
Open `https://YOUR-WORKER-URL/admin.html`, enter `ADMIN_TOKEN`, and review withdrawals. Mark paid only after the transfer is complete. Rejecting a pending request automatically refunds the user.

## 8. Test before launch
- Invalid/expired Telegram initData must be rejected.
- A new ad session must get a unique `ymid`.
- A valued Monetag test postback must credit once.
- Replaying the same postback must not credit again.
- A non-valued event must not credit.
- Test low-balance, minimum amount, and invalid Telebirr withdrawal requests.
- Reject a test withdrawal and confirm the refund.
- Reconcile test rewards with publisher reporting before enabling withdrawals.

## Architecture
Telegram Mini App → Cloudflare Worker API → Cloudflare D1.
Monetag server postback → `/postback/monetag` → idempotent reward ledger → user balance.
